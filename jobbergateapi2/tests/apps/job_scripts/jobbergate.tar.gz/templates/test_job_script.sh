#!/bin/bash

#SBATCH --job-name={{data.job_name}}
#SBATCH --partition={{data.partition}}
#SBATCH --output=sample-%j.out


echo $SLURM_TASKS_PER_NODE
echo $SLURM_SUBMIT_DIR
echo $SLURM_NODE_ALIASES
echo $SLURM_CLUSTER_NAME
echo $SLURM_JOB_CPUS_PER_NODE
echo $SLURM_JOB_PARTITION
echo $SLURM_JOB_NUM_NODES
echo $SLURM_JOBID
echo $SLURM_NODELIST
echo $SLURM_NNODES
echo $SLURM_SUBMIT_HOST
echo $SLURM_JOB_ID
echo $SLURM_CONF
echo $SLURM_JOB_NAME
echo $SLURM_JOB_NODELIST
