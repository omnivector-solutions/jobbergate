from jobbergate_cli.application_base import JobbergateApplicationBase
from jobbergate_cli import appform

# cory

class JobbergateApplication(JobbergateApplicationBase):

    def mainflow(self, data):
        questions = []

        questions.append(appform.List(
            variablename="partition",
            message="Choose slurm partition:",
            choices=self.application_config['partitions'],
        ))

        questions.append(appform.Text(
            variablename="job_name",
            message="Please enter a jobname",
            default=self.application_config['job_name']
        ))
        return questions
